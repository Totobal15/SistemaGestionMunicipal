from conexion import Database

class Funcionario:
    def __init__(self):
        self.db = Database()

    def agregar_funcionario(self, run, nombre_completo, tipo_licencia, fono):
        self.db.conectar()
        if not self.db.conexion:
            return False
        try:
            query = "INSERT INTO funcionario (run, nombre_completo, tipo_licencia, fono) VALUES (%s, %s, %s, %s)"
            valores = (run, nombre_completo, tipo_licencia, fono)
            self.db.cursor.execute(query, valores)
            self.db.conexion.commit()
            return True
        except Exception as e:
            print(f"Error al agregar funcionario: {str(e)}")
            return False
        finally:
            self.db.cerrar_conexion()

    def listar_funcionarios(self):
        self.db.conectar()
        if not self.db.conexion:
            return []
        try:
            query = "SELECT * FROM funcionario"
            self.db.cursor.execute(query)
            return self.db.cursor.fetchall()
        except Exception as e:
            print(f"Error al listar funcionarios: {str(e)}")
            return []
        finally:
            self.db.cerrar_conexion()

    def modificar_funcionario(self, run, nombre_completo, tipo_licencia, fono):
        self.db.conectar()
        if not self.db.conexion:
            return False
        try:
            query = "UPDATE funcionario SET nombre_completo = %s, tipo_licencia = %s, fono = %s WHERE run = %s"
            valores = (nombre_completo, tipo_licencia, fono, run)
            self.db.cursor.execute(query, valores)
            self.db.conexion.commit()
            return True
        except Exception as e:
            print(f"Error al modificar funcionario: {str(e)}")
            return False
        finally:
            self.db.cerrar_conexion()

    def eliminar_funcionario(self, run):
        self.db.conectar()
        if not self.db.conexion:
            return False
        try:
            query = "DELETE FROM funcionario WHERE run = %s"
            self.db.cursor.execute(query, (run,))
            self.db.conexion.commit()
            return self.db.cursor.rowcount > 0
        except Exception as e:
            print(f"Error al eliminar funcionario: {str(e)}")
            return False
        finally:
            self.db.cerrar_conexion()

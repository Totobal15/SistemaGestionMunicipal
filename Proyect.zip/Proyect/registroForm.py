import tkinter as tk
from tkinter import messagebox
from modelo.usuarioClass import Usuario
from PIL import Image, ImageTk

class RegistroForm:
    def __init__(self):
        # Configuración inicial de la ventana
        self.ventana = tk.Tk()
        self.ventana.title("Registro de Usuario")
        self.ventana.geometry("400x700")

        # Creación del frame principal
        self.frame_registro = tk.Frame(self.ventana, bg='#ede6db', padx=40, pady=40)
        self.frame_registro.place(relx=0.5, rely=0.5, anchor='center')

        # Carga y redimensionamiento del logo
        logo_original = Image.open("logola.png")
        logo_resized = logo_original.resize((150, 150), Image.LANCZOS)
        self.logo = ImageTk.PhotoImage(logo_resized)

        # Colocación del logo en la interfaz
        self.logo_label = tk.Label(self.frame_registro, image=self.logo, bg='#ede6db')
        self.logo_label.pack(pady=20)

        # Campos de entrada para el registro
        tk.Label(self.frame_registro, text="Nombre:", bg='#ede6db', font=("Arial", 14)).pack(pady=10)
        self.entry_nombre = tk.Entry(self.frame_registro, font=("Arial", 12), width=35)
        self.entry_nombre.pack(pady=10)

        tk.Label(self.frame_registro, text="Correo electrónico:", bg='#ede6db', font=("Arial", 14)).pack(pady=10)
        self.entry_email = tk.Entry(self.frame_registro, font=("Arial", 12), width=35)
        self.entry_email.pack(pady=10)

        tk.Label(self.frame_registro, text="Contraseña:", bg='#ede6db', font=("Arial", 14)).pack(pady=10)
        self.entry_password = tk.Entry(self.frame_registro, font=("Arial", 12), width=35, show="*")
        self.entry_password.pack(pady=10)

        # Botón de registro
        tk.Button(self.frame_registro, text="Registrar", command=self.registrar_usuario,
                  fg='black', font=("Arial", 14), padx=20, pady=10).pack(pady=30)

        # Carga y colocación del logo MDT
        mdt_logo_original = Image.open("mdt.png")
        mdt_logo_resized = mdt_logo_original.resize((80, 60), Image.LANCZOS)
        self.mdt_logo = ImageTk.PhotoImage(mdt_logo_resized)

        self.mdt_logo_label = tk.Label(self.ventana, image=self.mdt_logo, bg='#ede6db')
        self.mdt_logo_label.place(relx=0.95, rely=0.95, anchor='se')

        self.ventana.mainloop()

    def registrar_usuario(self):
        # Obtención de datos ingresados
        nombre = self.entry_nombre.get()
        email = self.entry_email.get()
        password = self.entry_password.get()
        
        # Intento de registro de usuario
        usuario = Usuario()
        if usuario.registrar_usuario(nombre, email, password):
            messagebox.showinfo("Éxito", "Usuario registrado correctamente")
            self.ventana.destroy()
            from loginForm import LoginForm
            LoginForm()
        else:
            messagebox.showerror("Error", "No se pudo registrar el usuario")

app = RegistroForm()
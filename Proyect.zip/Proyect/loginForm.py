import tkinter as tk
from tkinter import messagebox
from modelo.usuarioClass import Usuario
from PIL import Image, ImageTk
from mainForm import MainForm  # Importamos MainForm

class LoginForm:
    def __init__(self):
        # Configuración inicial de la ventana de login
        self.ventana = tk.Tk()
        self.ventana.title("Iniciar Sesión")
        self.ventana.geometry("400x700")

        # Creación del frame principal
        self.frame_login = tk.Frame(self.ventana, bg='#ede6db', padx=40, pady=40)
        self.frame_login.place(relx=0.5, rely=0.5, anchor='center')

        # Carga y redimensionamiento del logo
        logo_original = Image.open("logola.png")
        logo_resized = logo_original.resize((150, 150), Image.LANCZOS)
        self.logo = ImageTk.PhotoImage(logo_resized)

        # Colocación del logo en la interfaz
        self.logo_label = tk.Label(self.frame_login, image=self.logo, bg='#ede6db')
        self.logo_label.pack(pady=20)

        # Campos de entrada para el login
        tk.Label(self.frame_login, text="Email:", bg='#ede6db', font=("Arial", 14)).pack(pady=10)
        self.entry_email = tk.Entry(self.frame_login, font=("Arial", 12), width=35)
        self.entry_email.pack(pady=10)

        tk.Label(self.frame_login, text="Contraseña:", bg='#ede6db', font=("Arial", 14)).pack(pady=10)
        self.entry_password = tk.Entry(self.frame_login, show="*", font=("Arial", 12), width=35)
        self.entry_password.pack(pady=10)

        # Botón de inicio de sesión
        tk.Button(self.frame_login, text="Iniciar Sesión", command=self.iniciar_sesion,
                  fg='black', font=("Arial", 14), padx=20, pady=10).pack(pady=30)

        # Carga y colocación del logo MDT
        mdt_logo_original = Image.open("mdt.png")
        mdt_logo_resized = mdt_logo_original.resize((80, 60), Image.LANCZOS)
        self.mdt_logo = ImageTk.PhotoImage(mdt_logo_resized)

        self.mdt_logo_label = tk.Label(self.ventana, image=self.mdt_logo, bg='#ede6db')
        self.mdt_logo_label.place(relx=0.95, rely=0.95, anchor='se')

        self.ventana.mainloop()

    def iniciar_sesion(self):
        email = self.entry_email.get()
        password = self.entry_password.get()
        usuario = Usuario().verificar_usuario(email, password)
        if usuario:
            print(f"Usuario autenticado: {usuario}")
            usuario_actual = (usuario[0], usuario[1], usuario[2])  # ID, nombre, email
            self.ventana.destroy()
            MainForm(usuario_actual)
        else:
            messagebox.showerror("Error", "Credenciales incorrectas")

app = LoginForm()
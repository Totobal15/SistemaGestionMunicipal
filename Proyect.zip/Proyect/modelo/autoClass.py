from conexion import Database

class Automovil:
    def __init__(self):
        self.db = Database()

    def agregar_automovil(self, patente, marca, modelo):
        self.db.conectar()
        if not self.db.conexion:
            return False
        try:
            query = "INSERT INTO automovil (patente, marca, modelo) VALUES (%s, %s, %s)"
            valores = (patente, marca, modelo)
            self.db.cursor.execute(query, valores)
            self.db.conexion.commit()
            return True
        except Exception as e:
            print(f"Error al agregar automóvil: {str(e)}")
            return False
        finally:
            self.db.cerrar_conexion()

    def listar_automoviles(self):
        self.db.conectar()
        if not self.db.conexion:
            return []
        try:
            query = "SELECT * FROM automovil"
            self.db.cursor.execute(query)
            return self.db.cursor.fetchall()
        except Exception as e:
            print(f"Error al listar automóviles: {str(e)}")
            return []
        finally:
            self.db.cerrar_conexion()

    def modificar_auto(self, id_auto, marca, modelo, anio):
        self.db.conectar()
        if not self.db.conexion:
            return False
        try:
            query = "UPDATE auto SET marca = %s, modelo = %s, anio = %s WHERE id_usuario = %s"
            valores = (marca, modelo, anio, id_auto)
            self.db.cursor.execute(query, valores)
            self.db.conexion.commit()
            return True
        except Exception as e:
            print(f"Error al modificar auto: {str(e)}")
            return False
        finally:
            self.db.cerrar_conexion()

    def modificar_automovil(self, patente, nueva_marca, nuevo_modelo):
        self.db.conectar()
        if not self.db.conexion:
            return False
        try:
            query = "UPDATE automovil SET marca = %s, modelo = %s WHERE patente = %s"
            valores = (nueva_marca, nuevo_modelo, patente)
            self.db.cursor.execute(query, valores)
            filas_afectadas = self.db.cursor.rowcount
            self.db.conexion.commit()
            return filas_afectadas > 0
        except Exception as e:
            print(f"Error al modificar automóvil: {str(e)}")
            return False
        finally:
            self.db.cerrar_conexion()

    def eliminar_automovil(self, patente):
        self.db.conectar()
        if not self.db.conexion:
            return False
        try:
            query = "DELETE FROM automovil WHERE patente = %s"
            self.db.cursor.execute(query, (patente,))
            filas_afectadas = self.db.cursor.rowcount
            self.db.conexion.commit()
            return filas_afectadas > 0
        except Exception as e:
            print(f"Error al eliminar automóvil: {str(e)}")
            return False
        finally:
            self.db.cerrar_conexion()
from conexion import Database

class Registro:
    def __init__(self):
        self.db = Database()

    def registrar_usuario(self, nombre, email, password):
        self.db.conectar()
        if not self.db.conexion:
            print("No se pudo establecer conexión con la base de datos")
            return False
        try:
            query = "INSERT INTO usuario (nombre, email, password) VALUES (%s, %s, %s)"
            valores = (nombre, email, password)
            self.db.cursor.execute(query, valores)
            self.db.conexion.commit()
            return True
        except Exception as e:
            print(f"Error al registrar usuario: {str(e)}")
            return False
        finally:
            self.db.cerrar_conexion()

    def verificar_usuario_existente(self, email):
        self.db.conectar()
        if not self.db.conexion:
            print("No se pudo establecer conexión con la base de datos")
            return False
        try:
            query = "SELECT COUNT(*) FROM usuario WHERE email = %s"
            self.db.cursor.execute(query, (email,))
            count = self.db.cursor.fetchone()[0]
            return count > 0
        except Exception as e:
            print(f"Error al verificar usuario existente: {str(e)}")
            return False
        finally:
            self.db.cerrar_conexion()
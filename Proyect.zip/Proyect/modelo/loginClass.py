from conexion import Database

class Login:
    def __init__(self):
        self.db = Database()

    def validar_usuario(self, email, password):
        self.db.conectar()
        if not self.db.conexion:
            print("No se pudo establecer conexión con la base de datos")
            return False
        try:
            query = "SELECT * FROM usuario WHERE email = %s AND password = %s"
            valores = (email, password)
            self.db.cursor.execute(query, valores)
            usuario = self.db.cursor.fetchone()
            return usuario is not None
        except Exception as e:
            print(f"Error al validar usuario: {str(e)}")
            return False
        finally:
            self.db.cerrar_conexion()

import tkinter as tk
from tkinter import ttk, messagebox, simpledialog
from modelo.funcionarioClass import Funcionario
from modelo.autoClass import Automovil
from modelo.usuarioClass import Usuario
import datetime
from PIL import Image, ImageTk
import mysql.connector


def time_now():
    hora_actual = datetime.datetime.now()
    return hora_actual.strftime("%d/%m/%Y %H:%M:%S")

class MainForm:
    def __init__(self, usuario_actual):
        print(f"Iniciando MainForm con usuario: {usuario_actual}")  
        self.ventana = tk.Tk()
        self.ventana.geometry("1280x720")
        self.ventana.title(f"Intranet Municipal - Bienvenido, {usuario_actual[1]}")
        
        # Definir colores
        self.color_fondo = "#ede6db"  # Color vintage
        self.color_pestanas = "#1E88E5"  # Azul principal
        self.color_texto = "#333333"  # Gris oscuro
        self.color_botones = "#4CAF50"  # Verde
        
        self.ventana.configure(bg=self.color_fondo)
        
        self.usuario_actual = usuario_actual
        
        self.notebook = ttk.Notebook(self.ventana)
        self.notebook.pack(expand=True, fill="both")
        
        # Configurar estilo
        self.estilo = ttk.Style()
        self.estilo.theme_create("EstiloPersonalizado", parent="alt", settings={
            "TNotebook": {"configure": {"tabmargins": [2, 5, 2, 0], "background": self.color_fondo}},
            "TNotebook.Tab": {
                "configure": {"padding": [10, 5], "background": self.color_pestanas, "foreground": "white"},
                "map": {"background": [("selected", self.color_fondo)],
                        "foreground": [("selected", self.color_texto)],
                        "expand": [("selected", [1, 1, 1, 0])]}
            }
        })
        self.estilo.theme_use("EstiloPersonalizado")
        
        # Cargar y redimensionar el logo
        self.logo_original = tk.PhotoImage(file="logola.png")
        self.logo = self.logo_original.subsample(2, 2)  # Cambiado de 3,3 a 2,2 para hacerlo más grande

        # Cargar y redimensionar el logo mdt
        mdt_logo_original = Image.open("mdt.png")
        mdt_logo_resized = mdt_logo_original.resize((80, 60), Image.LANCZOS)  # Reducido el ancho a 80
        self.mdt_logo = ImageTk.PhotoImage(mdt_logo_resized)

        # Mostrar el logo mdt en la parte inferior derecha
        self.mdt_logo_label = tk.Label(self.ventana, image=self.mdt_logo, bg=self.color_fondo)
        self.mdt_logo_label.place(relx=0.95, rely=0.95, anchor='se')

        self.novedades()
        self.tabla_funcionarios()
        self.tabla_automoviles()
        self.perfil_usuario()
        
        self.ventana.mainloop()

    def agregar_logo(self, tab):
        # Crear un frame contenedor para el logo
        logo_frame = tk.Frame(tab, bg=self.color_fondo)
        logo_frame.place(relx=0.5, rely=0.05, anchor="n")
        
        # Añadir el logo al frame
        logo_label = tk.Label(logo_frame, image=self.logo, bg=self.color_fondo)
        logo_label.pack()

        # Ajustar la posición de los otros elementos
        for widget in tab.winfo_children():
            if widget != logo_frame:
                widget.place_configure(rely=0.3)  # Aumentado para dar más espacio al logo más grande

    def tabla_funcionarios(self):
        tab = ttk.Frame(self.notebook, style='TFrame')
        self.notebook.add(tab, text="Funcionarios")
        
        # Frame contenedor principal
        contenedor_principal = tk.Frame(tab, bg=self.color_fondo)
        contenedor_principal.pack(expand=True, fill="both")
        
        # Frame para el logo (a la derecha)
        frame_logo = tk.Frame(contenedor_principal, bg=self.color_fondo)
        frame_logo.pack(side="right", padx=20, pady=(20, 60))  # Cambiado de pady=60 a pady=(20, 60)
        
        # Añadir el logo al frame derecho
        logo_label = tk.Label(frame_logo, image=self.logo, bg=self.color_fondo)
        logo_label.pack()
        
        # Frame contenedor para los elementos de funcionarios (a la izquierda)
        contenedor = tk.Frame(contenedor_principal, bg=self.color_fondo)
        contenedor.pack(side="left", expand=True, padx=20, pady=20)
        
        # El resto del código para los elementos de funcionarios permanece igual
        tk.Label(contenedor, text="RUN:", bg=self.color_fondo, fg=self.color_texto).grid(row=0, column=0, sticky="e", pady=5)
        self.entry_run = tk.Entry(contenedor)
        self.entry_run.grid(row=0, column=1, pady=5)
        
        tk.Label(contenedor, text="Nombre Completo:", bg=self.color_fondo, fg=self.color_texto).grid(row=1, column=0, sticky="e", pady=5)
        self.entry_nombre_completo = tk.Entry(contenedor)
        self.entry_nombre_completo.grid(row=1, column=1, pady=5)
        
        tk.Label(contenedor, text="Tipo de Licencia:", bg=self.color_fondo, fg=self.color_texto).grid(row=2, column=0, sticky="e", pady=5)
        self.entry_tipo_licencia = tk.Entry(contenedor)
        self.entry_tipo_licencia.grid(row=2, column=1, pady=5)
        
        tk.Label(contenedor, text="Teléfono:", bg=self.color_fondo, fg=self.color_texto).grid(row=3, column=0, sticky="e", pady=5)
        self.entry_fono = tk.Entry(contenedor)
        self.entry_fono.grid(row=3, column=1, pady=5)
        
        tk.Button(contenedor, text="Agregar Funcionario", command=self.agregar_funcionario).grid(row=4, column=0, columnspan=2, pady=5)
        tk.Button(contenedor, text="Listar Funcionarios", command=self.listar_funcionarios).grid(row=5, column=0, columnspan=2, pady=5)
        tk.Button(contenedor, text="Modificar Funcionario", command=self.modificar_funcionario).grid(row=6, column=0, columnspan=2, pady=5)
        tk.Button(contenedor, text="Eliminar Funcionario", command=self.eliminar_funcionario).grid(row=7, column=0, columnspan=2, pady=5)

        # Crear un Treeview para mostrar la lista de funcionarios
        self.tree = ttk.Treeview(contenedor, columns=("RUN", "Nombre", "Licencia", "Teléfono"), show="headings")
        self.tree.heading("RUN", text="RUN")
        self.tree.heading("Nombre", text="Nombre Completo")
        self.tree.heading("Licencia", text="Tipo de Licencia")
        self.tree.heading("Teléfono", text="Teléfono")
        self.tree.grid(row=8, column=0, columnspan=2, pady=10)

        # Agregar una barra de desplazamiento
        scrollbar = ttk.Scrollbar(contenedor, orient="vertical", command=self.tree.yview)
        scrollbar.grid(row=8, column=2, sticky="ns")
        self.tree.configure(yscrollcommand=scrollbar.set)

        # Botón para actualizar la lista
        tk.Button(contenedor, text="Actualizar Lista", command=self.actualizar_lista_funcionarios).grid(row=9, column=0, columnspan=2, pady=5)

    def actualizar_lista_funcionarios(self):
        # Limpiar la tabla actual
        for i in self.tree.get_children():
            self.tree.delete(i)

        # Obtener la lista actualizada de funcionarios
        funcionario = Funcionario()
        funcionarios = funcionario.listar_funcionarios()

        # Insertar los datos en la tabla
        for f in funcionarios:
            self.tree.insert("", "end", values=f)

    def listar_funcionarios(self):
        self.actualizar_lista_funcionarios()

    def tabla_automoviles(self):
        tab = ttk.Frame(self.notebook, style='TFrame')
        self.notebook.add(tab, text="Automóviles")
        
        self.agregar_logo(tab)
        
        # Frame contenedor
        contenedor = tk.Frame(tab, bg=self.color_fondo)
        contenedor.place(relx=0.5, rely=0.5, anchor="center")
        
        tk.Label(contenedor, text="Patente:", bg=self.color_fondo, fg=self.color_texto).grid(row=0, column=0, sticky="e", pady=5)
        self.entry_patente = tk.Entry(contenedor)
        self.entry_patente.grid(row=0, column=1, pady=5)
        
        tk.Label(contenedor, text="Marca:", bg=self.color_fondo, fg=self.color_texto).grid(row=1, column=0, sticky="e", pady=5)
        self.entry_marca = tk.Entry(contenedor)
        self.entry_marca.grid(row=1, column=1, pady=5)
        
        tk.Label(contenedor, text="Modelo:", bg=self.color_fondo, fg=self.color_texto).grid(row=2, column=0, sticky="e", pady=5)
        self.entry_modelo = tk.Entry(contenedor)
        self.entry_modelo.grid(row=2, column=1, pady=5)
        
        tk.Button(contenedor, text="Agregar Automóvil", command=self.agregar_automovil).grid(row=3, column=0, columnspan=2, pady=5)
        tk.Button(contenedor, text="Listar Automóviles", command=self.listar_automoviles).grid(row=4, column=0, columnspan=2, pady=5)
        tk.Button(contenedor, text="Modificar Automóvil", command=self.modificar_automovil).grid(row=5, column=0, columnspan=2, pady=5)
        tk.Button(contenedor, text="Eliminar Automóvil", command=self.eliminar_automovil).grid(row=6, column=0, columnspan=2, pady=5)

        # Crear un Treeview para mostrar la lista de automóviles
        self.tree_autos = ttk.Treeview(contenedor, columns=("Patente", "Marca", "Modelo"), show="headings")
        self.tree_autos.heading("Patente", text="Patente")
        self.tree_autos.heading("Marca", text="Marca")
        self.tree_autos.heading("Modelo", text="Modelo")
        self.tree_autos.grid(row=7, column=0, columnspan=2, pady=10)

        # Agregar una barra de desplazamiento
        scrollbar = ttk.Scrollbar(contenedor, orient="vertical", command=self.tree_autos.yview)
        scrollbar.grid(row=7, column=2, sticky="ns")
        self.tree_autos.configure(yscrollcommand=scrollbar.set)

        # Botón para actualizar la lista
        tk.Button(contenedor, text="Actualizar Lista", command=self.actualizar_lista_automoviles).grid(row=8, column=0, columnspan=2, pady=5)

    def actualizar_lista_automoviles(self):
        # Limpiar la tabla actual
        for i in self.tree_autos.get_children():
            self.tree_autos.delete(i)

        # Obtener la lista actualizada de automóviles
        automovil = Automovil()
        automoviles = automovil.listar_automoviles()

        # Insertar los datos en la tabla
        for a in automoviles:
            self.tree_autos.insert("", "end", values=a)

    def listar_automoviles(self):
        self.actualizar_lista_automoviles()

    def perfil_usuario(self):
        tab = ttk.Frame(self.notebook, style='TFrame')
        self.notebook.add(tab, text="Gestión de Usuarios")
        
        self.agregar_logo(tab)
        
        contenedor = tk.Frame(tab, bg=self.color_fondo)
        contenedor.pack(expand=True)
        
        # Sección para modificar el perfil del usuario actual
        tk.Label(contenedor, text="Modificar tu perfil", font=("Arial", 14, "bold"), bg=self.color_fondo, fg=self.color_texto).pack(pady=(0, 10))
        
        tk.Label(contenedor, text="Nombre:", bg=self.color_fondo, fg=self.color_texto).pack()
        self.entry_nombre_usuario = tk.Entry(contenedor)
        self.entry_nombre_usuario.insert(0, self.usuario_actual[1])
        self.entry_nombre_usuario.pack(pady=5)
        
        tk.Label(contenedor, text="Email:", bg=self.color_fondo, fg=self.color_texto).pack()
        self.entry_email_usuario = tk.Entry(contenedor)
        self.entry_email_usuario.insert(0, self.usuario_actual[2])
        self.entry_email_usuario.pack(pady=5)
        
        tk.Button(contenedor, text="Modificar Perfil", command=self.modificar_perfil).pack(pady=10)
        
        # Separador
        ttk.Separator(contenedor, orient='horizontal').pack(fill='x', pady=20)
        
        # Sección para eliminar otros usuarios
        tk.Label(contenedor, text="Eliminar otros usuarios", font=("Arial", 14, "bold"), bg=self.color_fondo, fg=self.color_texto).pack(pady=(0, 10))
        
        tk.Label(contenedor, text="Email del usuario a eliminar:", bg=self.color_fondo, fg=self.color_texto).pack()
        self.entry_email_eliminar = tk.Entry(contenedor)
        self.entry_email_eliminar.pack(pady=5)
        
        tk.Button(contenedor, text="Eliminar Usuario", command=self.eliminar_usuario).pack(pady=10)
        
        # Separador
        ttk.Separator(contenedor, orient='horizontal').pack(fill='x', pady=20)
        
        # Nueva sección para eliminar la cuenta propia
        tk.Label(contenedor, text="Eliminar tu cuenta", font=("Arial", 14, "bold"), bg=self.color_fondo, fg=self.color_texto).pack(pady=(0, 10))
        
        tk.Button(contenedor, text="Eliminar mi cuenta", command=self.eliminar_cuenta_propia).pack(pady=10)

    def novedades(self):
        tab = ttk.Frame(self.notebook, style='TFrame')
        self.notebook.add(tab, text="Novedades")
        
        self.agregar_logo(tab)
        
        # Crear un frame contenedor
        contenedor = tk.Frame(tab, bg='#ede6db')
        contenedor.place(relx=0.5, rely=0.3, anchor="n")

        # Título y fecha
        self.titulo_novedades = tk.Label(contenedor, text="Portal de Novedades", font=("ADLaM Display", 20, "bold"), bg=self.color_fondo, fg=self.color_texto)
        self.titulo_novedades.pack(padx=5, pady=(20, 10))

        self.fecha_novedades = tk.Label(contenedor, text=f"Fecha de ingreso: {time_now()}", bg=self.color_fondo, fg=self.color_texto)
        self.fecha_novedades.pack(pady=(0, 20))

        self.noticia1 = tk.Label(contenedor, text="Noticia del día:", font=("Arial", 12), bg=self.color_fondo, fg=self.color_texto)
        self.noticia1.pack(pady=5)

        # Frame para contener las imágenes y los sensores
        frame_imagenes = tk.Frame(contenedor, bg=self.color_fondo)
        frame_imagenes.pack(pady=10)

        # Cargar y redimensionar las imágenes
        self.imagenes = []
        for imagen_file in ["imagen_novedades.png", "imagen_novedades2.png"]:
            imagen_original = tk.PhotoImage(file=imagen_file)
            factor_escala = 0.5
            imagen_redimensionada = imagen_original.subsample(int(1/factor_escala))
            self.imagenes.append(imagen_redimensionada)

        # Crear sensores (botones)
        self.boton_izquierdo = tk.Button(frame_imagenes, text="<", command=self.imagen_anterior)
        self.boton_izquierdo.pack(side=tk.LEFT, padx=10)

        # Crear y empaquetar el label con la imagen
        self.imagen_actual = 0
        self.imagen_label = tk.Label(frame_imagenes, image=self.imagenes[self.imagen_actual], cursor="hand2", bg=self.color_fondo)
        self.imagen_label.pack(side=tk.LEFT)
        self.imagen_label.bind("<Button-1>", self.abrir_enlace)

        self.boton_derecho = tk.Button(frame_imagenes, text=">", command=self.imagen_siguiente)
        self.boton_derecho.pack(side=tk.LEFT, padx=10)

    def imagen_anterior(self):
        self.imagen_actual = (self.imagen_actual - 1) % len(self.imagenes)
        self.imagen_label.config(image=self.imagenes[self.imagen_actual])

    def imagen_siguiente(self):
        self.imagen_actual = (self.imagen_actual + 1) % len(self.imagenes)
        self.imagen_label.config(image=self.imagenes[self.imagen_actual])

    def abrir_enlace(self, event):
        import webbrowser
        enlaces = [
            "https://sistemas.losangeles.cl/RHL/public/tramites/zoonosis",
            "https://www.losangeles.cl/"  # Añade aquí el enlace para la segunda imagen
        ]
        webbrowser.open(enlaces[self.imagen_actual])

    def agregar_funcionario(self):
        run = self.entry_run.get()
        nombre_completo = self.entry_nombre_completo.get()
        tipo_licencia = self.entry_tipo_licencia.get()
        fono = self.entry_fono.get()
        if run and nombre_completo and tipo_licencia and fono:
            funcionario = Funcionario()
            if funcionario.agregar_funcionario(run, nombre_completo, tipo_licencia, fono):
                messagebox.showinfo("Éxito", "Funcionario agregado correctamente")
                for entry in [self.entry_run, self.entry_nombre_completo, self.entry_tipo_licencia, self.entry_fono]:
                    entry.delete(0, tk.END)
            else:
                messagebox.showerror("Error", "No se pudo agregar el funcionario")
        else:
            messagebox.showerror("Error", "Por favor, complete todos los campos")

    def agregar_automovil(self):
        patente = self.entry_patente.get()
        marca = self.entry_marca.get()
        modelo = self.entry_modelo.get()
        if patente and marca and modelo:
            automovil = Automovil()
            if automovil.agregar_automovil(patente, marca, modelo):
                messagebox.showinfo("Éxito", "Automóvil agregado correctamente")
                for entry in [self.entry_patente, self.entry_marca, self.entry_modelo]:
                    entry.delete(0, tk.END)
            else:
                messagebox.showerror("Error", "No se pudo agregar el automóvil")
        else:
            messagebox.showerror("Error", "Por favor, complete todos los campos")

    def modificar_funcionario(self):
        run = self.entry_run.get()
        if run:
            nombre_completo = self.entry_nombre_completo.get()
            tipo_licencia = self.entry_tipo_licencia.get()
            fono = self.entry_fono.get()
            if nombre_completo and tipo_licencia and fono:
                funcionario = Funcionario()
                if funcionario.modificar_funcionario(run, nombre_completo, tipo_licencia, fono):
                    messagebox.showinfo("Éxito", "Funcionario modificado correctamente")
                else:
                    messagebox.showerror("Error", "No se pudo modificar el funcionario")
            else:
                messagebox.showerror("Error", "Por favor, complete todos los campos")
        else:
            messagebox.showerror("Error", "Por favor, ingrese el RUN del funcionario a modificar")

    def modificar_automovil(self):
        patente = self.entry_patente.get()
        if patente:
            nueva_marca = self.entry_marca.get()
            nuevo_modelo = self.entry_modelo.get()
            if nueva_marca and nuevo_modelo:
                automovil = Automovil()
                resultado = automovil.modificar_automovil(patente, nueva_marca, nuevo_modelo)
                if resultado:
                    messagebox.showinfo("Éxito", "Automóvil modificado correctamente")
                    self.limpiar_campos_automovil()
                else:
                    messagebox.showerror("Error", "No se encontró un automóvil con esa patente o no se realizaron cambios")
            else:
                messagebox.showerror("Error", "Por favor, complete todos los campos")
        else:
            messagebox.showerror("Error", "Por favor, ingrese la patente del automóvil a modificar")

    def limpiar_campos_automovil(self):
        self.entry_patente.delete(0, tk.END)
        self.entry_marca.delete(0, tk.END)
        self.entry_modelo.delete(0, tk.END)

    def modificar_perfil(self):
        nombre = self.entry_nombre_usuario.get()
        email = self.entry_email_usuario.get()
        if nombre and email:
            usuario = Usuario()
            if usuario.modificar_usuario(self.usuario_actual[0], nombre, email):
                messagebox.showinfo("Éxito", "Perfil modificado correctamente")
                self.usuario_actual = (self.usuario_actual[0], nombre, email)
                self.ventana.title(f"Intranet Municipal - Bienvenido, {nombre}")
                
                # Actualizar los campos de entrada con los nuevos valores
                self.entry_nombre_usuario.delete(0, tk.END)
                self.entry_nombre_usuario.insert(0, nombre)
                self.entry_email_usuario.delete(0, tk.END)
                self.entry_email_usuario.insert(0, email)
            else:
                messagebox.showerror("Error", "No se pudo modificar el perfil")
        else:
            messagebox.showerror("Error", "Por favor, complete todos los campos")

    def eliminar_usuario(self):
        email = self.entry_email_eliminar.get()
        if not email:
            messagebox.showerror("Error", "Por favor, ingrese el email del usuario a eliminar.")
            return
        
        if messagebox.askyesno("Confirmar eliminación", f"¿Estás seguro de que quieres eliminar la cuenta con el email {email}? Esta acción no se puede deshacer."):
            usuario = Usuario()
            resultado = usuario.eliminar_usuario_por_email(email)
            if resultado:
                messagebox.showinfo("Éxito", f"La cuenta con el email {email} ha sido eliminada.")
                self.entry_email_eliminar.delete(0, tk.END)
            else:
                messagebox.showerror("Error", f"No se pudo eliminar la cuenta con el email {email}. Verifica que el email sea correcto.")

    def eliminar_cuenta_propia(self):
        if messagebox.askyesno("Confirmar eliminación", "¿Estás seguro de que quieres eliminar tu cuenta? Esta acción no se puede deshacer."):
            usuario = Usuario()
            
            print(f"ID del usuario actual: {self.usuario_actual[0]}")  
            
            # Verificar si el usuario existe
            if not usuario.verificar_existencia(self.usuario_actual[0]):
                error_message = usuario.get_last_error()
                messagebox.showerror("Error", f"No se encontró tu cuenta en la base de datos. Error: {error_message}")
                return
            
            print("El usuario existe en la base de datos.")  
            
            print(f"Intentando eliminar usuario con ID: {self.usuario_actual[0]}")  
            resultado = usuario.eliminar_usuario(self.usuario_actual[0])
            print(f"Resultado de la eliminación: {resultado}")  
            
            if resultado:
                messagebox.showinfo("Éxito", "Tu cuenta ha sido eliminada. La aplicación se cerrará ahora.")
                self.ventana.quit()
            else:
                error_message = usuario.get_last_error()
                messagebox.showerror("Error", f"No se pudo eliminar tu cuenta. Error: {error_message}")

    def eliminar_funcionario(self):
        run = self.entry_run.get()
        if run:
            if messagebox.askyesno("Confirmar eliminación", f"¿Estás seguro de que quieres eliminar al funcionario con RUN {run}?"):
                funcionario = Funcionario()
                if funcionario.eliminar_funcionario(run):
                    messagebox.showinfo("Éxito", "Funcionario eliminado correctamente")
                    self.limpiar_campos_funcionario()
                else:
                    messagebox.showerror("Error", "No se pudo eliminar al funcionario")
        else:
            messagebox.showerror("Error", "Por favor, ingrese el RUN del funcionario a eliminar")

    def eliminar_automovil(self):
        patente = self.entry_patente.get()
        if patente:
            if messagebox.askyesno("Confirmar eliminación", f"¿Estás seguro de que quieres eliminar el automóvil con patente {patente}?"):
                automovil = Automovil()
                resultado = automovil.eliminar_automovil(patente)
                if resultado:
                    messagebox.showinfo("Éxito", f"Automóvil con patente {patente} eliminado correctamente")
                    self.limpiar_campos_automovil()
                else:
                    messagebox.showerror("Error", f"No se pudo eliminar el automóvil con patente {patente}. Verifica que la patente exista en la base de datos.")
        else:
            messagebox.showerror("Error", "Por favor, ingrese la patente del automóvil a eliminar")

    def limpiar_campos_funcionario(self):
        self.entry_run.delete(0, tk.END)
        self.entry_nombre_completo.delete(0, tk.END)
        self.entry_tipo_licencia.delete(0, tk.END)
        self.entry_fono.delete(0, tk.END)


usuario_ejemplo = (11, "Usuario de Prueba", "usuario@ejemplo.com")
app = MainForm(usuario_ejemplo)
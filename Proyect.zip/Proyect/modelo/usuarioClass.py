from conexion import Database
import bcrypt

class Usuario:
    def __init__(self):
        self.db = Database()
        self.last_error = None

    def registrar_usuario(self, nombre, email, password):
        self.db.conectar()
        if not self.db.conexion:
            return False
        try:
            hashed_password = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt())
            query = "INSERT INTO usuario (nombre, email, password) VALUES (%s, %s, %s)"
            valores = (nombre, email, hashed_password)
            self.db.cursor.execute(query, valores)
            self.db.conexion.commit()
            return True
        except Exception as e:
            print(f"Error al registrar usuario: {str(e)}")
            return False
        finally:
            self.db.cerrar_conexion()

    def verificar_usuario(self, email, password):
        self.db.conectar()
        if not self.db.conexion:
            return None
        try:
            query = "SELECT * FROM usuario WHERE email = %s"
            self.db.cursor.execute(query, (email,))
            usuario = self.db.cursor.fetchone()
            if usuario and bcrypt.checkpw(password.encode('utf-8'), usuario[3].encode('utf-8')):
                return usuario
            return None
        except Exception as e:
            print(f"Error al verificar usuario: {str(e)}")
            return None
        finally:
            self.db.cerrar_conexion()

    def modificar_usuario(self, id_usuario, nombre, email):
        self.db.conectar()
        if not self.db.conexion:
            return False
        try:
            query = "UPDATE usuario SET nombre = %s, email = %s WHERE id_usuario = %s"
            valores = (nombre, email, id_usuario)
            self.db.cursor.execute(query, valores)
            self.db.conexion.commit()
            return True
        except Exception as e:
            print(f"Error al modificar usuario: {str(e)}")
            return False
        finally:
            self.db.cerrar_conexion()

    def eliminar_usuario(self, id_usuario):
        self.db.conectar()
        if not self.db.conexion:
            self.last_error = "No se pudo conectar a la base de datos"
            return False
        try:
            query = "DELETE FROM usuario WHERE id_usuario = %s"
            self.db.cursor.execute(query, (id_usuario,))
            if self.db.cursor.rowcount > 0:
                self.db.conexion.commit()
                print(f"Usuario con ID {id_usuario} eliminado correctamente")  # Depuración
                return True
            else:
                self.last_error = f"No se encontró un usuario con ID {id_usuario}"
                print(f"Error en eliminar_usuario: {self.last_error}")  # Depuración
                return False
        except Exception as e:
            self.last_error = f"Error al eliminar usuario: {str(e)}"
            print(f"Excepción en eliminar_usuario: {self.last_error}")  # Depuración
            return False
        finally:
            self.db.cerrar_conexion()

    def get_last_error(self):
        return self.last_error

    def verificar_existencia(self, id_usuario):
        self.db.conectar()
        if not self.db.conexion:
            self.last_error = "No se pudo conectar a la base de datos"
            return False
        try:
            query = "SELECT * FROM usuario WHERE id_usuario = %s"
            self.db.cursor.execute(query, (id_usuario,))
            resultado = self.db.cursor.fetchone() is not None
            print(f"Verificación de existencia para ID {id_usuario}: {resultado}")  # Depuración
            return resultado
        except Exception as e:
            self.last_error = f"Error al verificar existencia de usuario: {str(e)}"
            print(f"Error en verificar_existencia: {self.last_error}")  # Depuración
            return False
        finally:
            self.db.cerrar_conexion()

